# banking-project
This project contains a series of exercises focused on demonstrating the Object Oriented Principles (OOP) and Java code styles
