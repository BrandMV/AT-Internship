package com.at.internship.domain;

public class BankingAccount {
}
