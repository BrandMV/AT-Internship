package com.at.internship.domain;

public class BankingAccountTest {
}
