package interfaces;

public interface IMedidas {

    double calcularPerimetro();

    double calcularArea();
}