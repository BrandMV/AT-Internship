package abstracts;

public class FiguraGeometrica {

    protected double perimetro;
    protected double area;
}