package com.brandmv.relaciones2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Relaciones2Application {

    public static void main(String[] args) {
        SpringApplication.run(Relaciones2Application.class, args);
    }

}
