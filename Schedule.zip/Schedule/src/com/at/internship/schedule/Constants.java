package com.at.internship.schedule;

import java.io.File;

public class Constants {
    public static final String SERIALIZATION_PATH = "." + File.separator;
}
