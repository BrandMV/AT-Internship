package com.at.internship.rest.hello.service;

public interface IPoliteSalutation {
    String getPoliteSalutation();
}
