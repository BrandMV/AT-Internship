package com.lordcodemx.springrest.controllers;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
public class ClientesController {

    //@ResponseStatus(HttpStatus.CREATED)
    @RequestMapping("/saludo")
    public ResponseEntity<String> saludo() {
        String saludo = "Hello World!";
        return new ResponseEntity<String>(saludo, HttpStatus.OK);
        //return ResponseEntity.ok().build();
    }

    @GetMapping("/saludo/{nombre}")
    public ResponseEntity<String> saludoConNombrePathParameter(
            @PathVariable
            String nombre) {
        String response;

        if (nombre.length() < 2) {
            response = "Nombre inválido";
            return new ResponseEntity<String>(response, HttpStatus.BAD_REQUEST);
        }

        response = "Saludos " + nombre;
        return new ResponseEntity<String>(response, HttpStatus.OK);
        //return ResponseEntity.ok().build();
    }

    /**
     * Crear Handler:
     * GET
     * QueryParams Nombre, Apellido, Fecha de Nacimiento, Numero Cliente
     * ResponseEntity<ClienteResponse>
     *      Nombre : String
     *      Apellido : String
     *      Fecha Nacimiento (yyyy-mm-dd) : String
     *      Numero Cliente : long
     * Status Code: 200
     * Nombre > 3 digitos, apellido > 2 digitos, numero cliente > 5 digitos : BAD REQUEST
     */
}